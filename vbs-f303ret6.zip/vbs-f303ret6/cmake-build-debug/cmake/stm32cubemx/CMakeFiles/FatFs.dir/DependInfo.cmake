
# Consider dependencies only in project.
set(CMAKE_DEPENDS_IN_PROJECT_ONLY OFF)

# The set of languages for which implicit dependencies are needed:
set(CMAKE_DEPENDS_LANGUAGES
  )

# The set of dependency files which are needed:
set(CMAKE_DEPENDS_DEPENDENCY_FILES
  "D:/PROJECTS/liquidrocketry/Projects/VibrationSensor/FIS-Vibration-Sensor-Driver/vbs-f303ret6/Middlewares/Third_Party/FatFs/src/diskio.c" "cmake/stm32cubemx/CMakeFiles/FatFs.dir/__/__/Middlewares/Third_Party/FatFs/src/diskio.c.obj" "gcc" "cmake/stm32cubemx/CMakeFiles/FatFs.dir/__/__/Middlewares/Third_Party/FatFs/src/diskio.c.obj.d"
  "D:/PROJECTS/liquidrocketry/Projects/VibrationSensor/FIS-Vibration-Sensor-Driver/vbs-f303ret6/Middlewares/Third_Party/FatFs/src/ff.c" "cmake/stm32cubemx/CMakeFiles/FatFs.dir/__/__/Middlewares/Third_Party/FatFs/src/ff.c.obj" "gcc" "cmake/stm32cubemx/CMakeFiles/FatFs.dir/__/__/Middlewares/Third_Party/FatFs/src/ff.c.obj.d"
  "D:/PROJECTS/liquidrocketry/Projects/VibrationSensor/FIS-Vibration-Sensor-Driver/vbs-f303ret6/Middlewares/Third_Party/FatFs/src/ff_gen_drv.c" "cmake/stm32cubemx/CMakeFiles/FatFs.dir/__/__/Middlewares/Third_Party/FatFs/src/ff_gen_drv.c.obj" "gcc" "cmake/stm32cubemx/CMakeFiles/FatFs.dir/__/__/Middlewares/Third_Party/FatFs/src/ff_gen_drv.c.obj.d"
  "D:/PROJECTS/liquidrocketry/Projects/VibrationSensor/FIS-Vibration-Sensor-Driver/vbs-f303ret6/Middlewares/Third_Party/FatFs/src/option/syscall.c" "cmake/stm32cubemx/CMakeFiles/FatFs.dir/__/__/Middlewares/Third_Party/FatFs/src/option/syscall.c.obj" "gcc" "cmake/stm32cubemx/CMakeFiles/FatFs.dir/__/__/Middlewares/Third_Party/FatFs/src/option/syscall.c.obj.d"
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_LINKED_INFO_FILES
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_FORWARD_LINKED_INFO_FILES
  )

# Fortran module output directory.
set(CMAKE_Fortran_TARGET_MODULE_DIR "")
