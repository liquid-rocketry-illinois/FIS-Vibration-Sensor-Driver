file(REMOVE_RECURSE
  "CMakeFiles/vbs-f303ret6.dir/Core/Src/main.c.obj"
  "CMakeFiles/vbs-f303ret6.dir/Core/Src/main.c.obj.d"
  "CMakeFiles/vbs-f303ret6.dir/Core/Src/stm32f3xx_hal_msp.c.obj"
  "CMakeFiles/vbs-f303ret6.dir/Core/Src/stm32f3xx_hal_msp.c.obj.d"
  "CMakeFiles/vbs-f303ret6.dir/Core/Src/stm32f3xx_it.c.obj"
  "CMakeFiles/vbs-f303ret6.dir/Core/Src/stm32f3xx_it.c.obj.d"
  "CMakeFiles/vbs-f303ret6.dir/Core/Src/syscalls.c.obj"
  "CMakeFiles/vbs-f303ret6.dir/Core/Src/syscalls.c.obj.d"
  "CMakeFiles/vbs-f303ret6.dir/Core/Src/sysmem.c.obj"
  "CMakeFiles/vbs-f303ret6.dir/Core/Src/sysmem.c.obj.d"
  "CMakeFiles/vbs-f303ret6.dir/FATFS/App/fatfs.c.obj"
  "CMakeFiles/vbs-f303ret6.dir/FATFS/App/fatfs.c.obj.d"
  "CMakeFiles/vbs-f303ret6.dir/FATFS/App/initialization.c.obj"
  "CMakeFiles/vbs-f303ret6.dir/FATFS/App/initialization.c.obj.d"
  "CMakeFiles/vbs-f303ret6.dir/FATFS/Target/logging.c.obj"
  "CMakeFiles/vbs-f303ret6.dir/FATFS/Target/logging.c.obj.d"
  "CMakeFiles/vbs-f303ret6.dir/FATFS/Target/user_diskio.c.obj"
  "CMakeFiles/vbs-f303ret6.dir/FATFS/Target/user_diskio.c.obj.d"
  "CMakeFiles/vbs-f303ret6.dir/startup_stm32f303xe.s.obj"
  "vbs-f303ret6.map"
  "vbs-f303ret6.elf"
  "vbs-f303ret6.elf.manifest"
  "vbs-f303ret6.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang ASM C)
  include(CMakeFiles/vbs-f303ret6.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
