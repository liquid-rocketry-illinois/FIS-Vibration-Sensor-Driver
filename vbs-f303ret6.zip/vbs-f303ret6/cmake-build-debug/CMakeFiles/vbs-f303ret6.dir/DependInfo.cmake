
# Consider dependencies only in project.
set(CMAKE_DEPENDS_IN_PROJECT_ONLY OFF)

# The set of languages for which implicit dependencies are needed:
set(CMAKE_DEPENDS_LANGUAGES
  "ASM"
  )
# The set of files for implicit dependencies of each language:
set(CMAKE_DEPENDS_CHECK_ASM
  "D:/PROJECTS/liquidrocketry/Projects/VibrationSensor/FIS-Vibration-Sensor-Driver/vbs-f303ret6/startup_stm32f303xe.s" "D:/PROJECTS/liquidrocketry/Projects/VibrationSensor/FIS-Vibration-Sensor-Driver/vbs-f303ret6/cmake-build-debug/CMakeFiles/vbs-f303ret6.dir/startup_stm32f303xe.s.obj"
  )
set(CMAKE_ASM_COMPILER_ID "GNU")

# Preprocessor definitions for this target.
set(CMAKE_TARGET_DEFINITIONS_ASM
  "DEBUG"
  "STM32F303xE"
  "USE_HAL_DRIVER"
  )

# The include file search paths:
set(CMAKE_ASM_TARGET_INCLUDE_PATH
  "D:/PROJECTS/liquidrocketry/Projects/VibrationSensor/FIS-Vibration-Sensor-Driver/vbs-f303ret6/cmake/stm32cubemx/../../FATFS/Target"
  "D:/PROJECTS/liquidrocketry/Projects/VibrationSensor/FIS-Vibration-Sensor-Driver/vbs-f303ret6/cmake/stm32cubemx/../../FATFS/App"
  "D:/PROJECTS/liquidrocketry/Projects/VibrationSensor/FIS-Vibration-Sensor-Driver/vbs-f303ret6/cmake/stm32cubemx/../../Core/Inc"
  "D:/PROJECTS/liquidrocketry/Projects/VibrationSensor/FIS-Vibration-Sensor-Driver/vbs-f303ret6/cmake/stm32cubemx/../../Drivers/STM32F3xx_HAL_Driver/Inc/Legacy"
  "D:/PROJECTS/liquidrocketry/Projects/VibrationSensor/FIS-Vibration-Sensor-Driver/vbs-f303ret6/cmake/stm32cubemx/../../Drivers/STM32F3xx_HAL_Driver/Inc"
  "D:/PROJECTS/liquidrocketry/Projects/VibrationSensor/FIS-Vibration-Sensor-Driver/vbs-f303ret6/cmake/stm32cubemx/../../Middlewares/Third_Party/FatFs/src"
  "D:/PROJECTS/liquidrocketry/Projects/VibrationSensor/FIS-Vibration-Sensor-Driver/vbs-f303ret6/cmake/stm32cubemx/../../Drivers/CMSIS/Device/ST/STM32F3xx/Include"
  "D:/PROJECTS/liquidrocketry/Projects/VibrationSensor/FIS-Vibration-Sensor-Driver/vbs-f303ret6/cmake/stm32cubemx/../../Drivers/CMSIS/Include"
  )

# The set of dependency files which are needed:
set(CMAKE_DEPENDS_DEPENDENCY_FILES
  "D:/PROJECTS/liquidrocketry/Projects/VibrationSensor/FIS-Vibration-Sensor-Driver/vbs-f303ret6/Core/Src/main.c" "CMakeFiles/vbs-f303ret6.dir/Core/Src/main.c.obj" "gcc" "CMakeFiles/vbs-f303ret6.dir/Core/Src/main.c.obj.d"
  "D:/PROJECTS/liquidrocketry/Projects/VibrationSensor/FIS-Vibration-Sensor-Driver/vbs-f303ret6/Core/Src/stm32f3xx_hal_msp.c" "CMakeFiles/vbs-f303ret6.dir/Core/Src/stm32f3xx_hal_msp.c.obj" "gcc" "CMakeFiles/vbs-f303ret6.dir/Core/Src/stm32f3xx_hal_msp.c.obj.d"
  "D:/PROJECTS/liquidrocketry/Projects/VibrationSensor/FIS-Vibration-Sensor-Driver/vbs-f303ret6/Core/Src/stm32f3xx_it.c" "CMakeFiles/vbs-f303ret6.dir/Core/Src/stm32f3xx_it.c.obj" "gcc" "CMakeFiles/vbs-f303ret6.dir/Core/Src/stm32f3xx_it.c.obj.d"
  "D:/PROJECTS/liquidrocketry/Projects/VibrationSensor/FIS-Vibration-Sensor-Driver/vbs-f303ret6/Core/Src/syscalls.c" "CMakeFiles/vbs-f303ret6.dir/Core/Src/syscalls.c.obj" "gcc" "CMakeFiles/vbs-f303ret6.dir/Core/Src/syscalls.c.obj.d"
  "D:/PROJECTS/liquidrocketry/Projects/VibrationSensor/FIS-Vibration-Sensor-Driver/vbs-f303ret6/Core/Src/sysmem.c" "CMakeFiles/vbs-f303ret6.dir/Core/Src/sysmem.c.obj" "gcc" "CMakeFiles/vbs-f303ret6.dir/Core/Src/sysmem.c.obj.d"
  "D:/PROJECTS/liquidrocketry/Projects/VibrationSensor/FIS-Vibration-Sensor-Driver/vbs-f303ret6/FATFS/App/fatfs.c" "CMakeFiles/vbs-f303ret6.dir/FATFS/App/fatfs.c.obj" "gcc" "CMakeFiles/vbs-f303ret6.dir/FATFS/App/fatfs.c.obj.d"
  "D:/PROJECTS/liquidrocketry/Projects/VibrationSensor/FIS-Vibration-Sensor-Driver/vbs-f303ret6/FATFS/App/initialization.c" "CMakeFiles/vbs-f303ret6.dir/FATFS/App/initialization.c.obj" "gcc" "CMakeFiles/vbs-f303ret6.dir/FATFS/App/initialization.c.obj.d"
  "D:/PROJECTS/liquidrocketry/Projects/VibrationSensor/FIS-Vibration-Sensor-Driver/vbs-f303ret6/FATFS/Target/logging.c" "CMakeFiles/vbs-f303ret6.dir/FATFS/Target/logging.c.obj" "gcc" "CMakeFiles/vbs-f303ret6.dir/FATFS/Target/logging.c.obj.d"
  "D:/PROJECTS/liquidrocketry/Projects/VibrationSensor/FIS-Vibration-Sensor-Driver/vbs-f303ret6/FATFS/Target/user_diskio.c" "CMakeFiles/vbs-f303ret6.dir/FATFS/Target/user_diskio.c.obj" "gcc" "CMakeFiles/vbs-f303ret6.dir/FATFS/Target/user_diskio.c.obj.d"
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_LINKED_INFO_FILES
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_FORWARD_LINKED_INFO_FILES
  )

# Fortran module output directory.
set(CMAKE_Fortran_TARGET_MODULE_DIR "")
