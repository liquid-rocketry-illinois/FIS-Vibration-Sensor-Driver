CMakeFiles/vbs-f303ret6.dir/FATFS/App/initialization.c.obj: \
 D:\PROJECTS\liquidrocketry\Projects\VibrationSensor\FIS-Vibration-Sensor-Driver\vbs-f303ret6\FATFS\App\initialization.c \
 D:\PROJECTS\liquidrocketry\Projects\VibrationSensor\FIS-Vibration-Sensor-Driver\vbs-f303ret6\FATFS\App\fatfs.h \
 D:/PROJECTS/liquidrocketry/Projects/VibrationSensor/FIS-Vibration-Sensor-Driver/vbs-f303ret6/Middlewares/Third_Party/FatFs/src/ff.h \
 D:/PROJECTS/liquidrocketry/Projects/VibrationSensor/FIS-Vibration-Sensor-Driver/vbs-f303ret6/Middlewares/Third_Party/FatFs/src/integer.h \
 D:/PROJECTS/liquidrocketry/Projects/VibrationSensor/FIS-Vibration-Sensor-Driver/vbs-f303ret6/FATFS/Target/ffconf.h \
 D:/PROJECTS/liquidrocketry/Projects/VibrationSensor/FIS-Vibration-Sensor-Driver/vbs-f303ret6/Core/Inc/main.h \
 D:/PROJECTS/liquidrocketry/Projects/VibrationSensor/FIS-Vibration-Sensor-Driver/vbs-f303ret6/Drivers/STM32F3xx_HAL_Driver/Inc/stm32f3xx_hal.h \
 D:/PROJECTS/liquidrocketry/Projects/VibrationSensor/FIS-Vibration-Sensor-Driver/vbs-f303ret6/Core/Inc/stm32f3xx_hal_conf.h \
 D:/PROJECTS/liquidrocketry/Projects/VibrationSensor/FIS-Vibration-Sensor-Driver/vbs-f303ret6/Drivers/STM32F3xx_HAL_Driver/Inc/stm32f3xx_hal_rcc.h \
 D:/PROJECTS/liquidrocketry/Projects/VibrationSensor/FIS-Vibration-Sensor-Driver/vbs-f303ret6/Drivers/STM32F3xx_HAL_Driver/Inc/stm32f3xx_hal_def.h \
 D:/PROJECTS/liquidrocketry/Projects/VibrationSensor/FIS-Vibration-Sensor-Driver/vbs-f303ret6/Drivers/CMSIS/Device/ST/STM32F3xx/Include/stm32f3xx.h \
 D:/PROJECTS/liquidrocketry/Projects/VibrationSensor/FIS-Vibration-Sensor-Driver/vbs-f303ret6/Drivers/CMSIS/Device/ST/STM32F3xx/Include/stm32f303xe.h \
 D:/PROJECTS/liquidrocketry/Projects/VibrationSensor/FIS-Vibration-Sensor-Driver/vbs-f303ret6/Drivers/CMSIS/Include/core_cm4.h \
 C:/Program\ Files/Arm/GNU\ Toolchain\ mingw-w64-x86_64-arm-none-eabi/lib/gcc/arm-none-eabi/15.2.1/include/stdint.h \
 C:/Program\ Files/Arm/GNU\ Toolchain\ mingw-w64-x86_64-arm-none-eabi/arm-none-eabi/include/stdint.h \
 C:/Program\ Files/Arm/GNU\ Toolchain\ mingw-w64-x86_64-arm-none-eabi/arm-none-eabi/include/machine/_default_types.h \
 C:/Program\ Files/Arm/GNU\ Toolchain\ mingw-w64-x86_64-arm-none-eabi/arm-none-eabi/include/sys/features.h \
 C:/Program\ Files/Arm/GNU\ Toolchain\ mingw-w64-x86_64-arm-none-eabi/arm-none-eabi/include/_newlib_version.h \
 C:/Program\ Files/Arm/GNU\ Toolchain\ mingw-w64-x86_64-arm-none-eabi/arm-none-eabi/include/sys/_intsup.h \
 C:/Program\ Files/Arm/GNU\ Toolchain\ mingw-w64-x86_64-arm-none-eabi/arm-none-eabi/include/sys/_stdint.h \
 D:/PROJECTS/liquidrocketry/Projects/VibrationSensor/FIS-Vibration-Sensor-Driver/vbs-f303ret6/Drivers/CMSIS/Include/cmsis_version.h \
 D:/PROJECTS/liquidrocketry/Projects/VibrationSensor/FIS-Vibration-Sensor-Driver/vbs-f303ret6/Drivers/CMSIS/Include/cmsis_compiler.h \
 D:/PROJECTS/liquidrocketry/Projects/VibrationSensor/FIS-Vibration-Sensor-Driver/vbs-f303ret6/Drivers/CMSIS/Include/cmsis_gcc.h \
 D:/PROJECTS/liquidrocketry/Projects/VibrationSensor/FIS-Vibration-Sensor-Driver/vbs-f303ret6/Drivers/CMSIS/Include/mpu_armv7.h \
 D:/PROJECTS/liquidrocketry/Projects/VibrationSensor/FIS-Vibration-Sensor-Driver/vbs-f303ret6/Drivers/CMSIS/Device/ST/STM32F3xx/Include/system_stm32f3xx.h \
 D:/PROJECTS/liquidrocketry/Projects/VibrationSensor/FIS-Vibration-Sensor-Driver/vbs-f303ret6/Drivers/STM32F3xx_HAL_Driver/Inc/Legacy/stm32_hal_legacy.h \
 C:/Program\ Files/Arm/GNU\ Toolchain\ mingw-w64-x86_64-arm-none-eabi/lib/gcc/arm-none-eabi/15.2.1/include/stddef.h \
 D:/PROJECTS/liquidrocketry/Projects/VibrationSensor/FIS-Vibration-Sensor-Driver/vbs-f303ret6/Drivers/STM32F3xx_HAL_Driver/Inc/stm32f3xx_hal_rcc_ex.h \
 D:/PROJECTS/liquidrocketry/Projects/VibrationSensor/FIS-Vibration-Sensor-Driver/vbs-f303ret6/Drivers/STM32F3xx_HAL_Driver/Inc/stm32f3xx_hal_gpio.h \
 D:/PROJECTS/liquidrocketry/Projects/VibrationSensor/FIS-Vibration-Sensor-Driver/vbs-f303ret6/Drivers/STM32F3xx_HAL_Driver/Inc/stm32f3xx_hal_gpio_ex.h \
 D:/PROJECTS/liquidrocketry/Projects/VibrationSensor/FIS-Vibration-Sensor-Driver/vbs-f303ret6/Drivers/STM32F3xx_HAL_Driver/Inc/stm32f3xx_hal_exti.h \
 D:/PROJECTS/liquidrocketry/Projects/VibrationSensor/FIS-Vibration-Sensor-Driver/vbs-f303ret6/Drivers/STM32F3xx_HAL_Driver/Inc/stm32f3xx_hal_dma.h \
 D:/PROJECTS/liquidrocketry/Projects/VibrationSensor/FIS-Vibration-Sensor-Driver/vbs-f303ret6/Drivers/STM32F3xx_HAL_Driver/Inc/stm32f3xx_hal_dma_ex.h \
 D:/PROJECTS/liquidrocketry/Projects/VibrationSensor/FIS-Vibration-Sensor-Driver/vbs-f303ret6/Drivers/STM32F3xx_HAL_Driver/Inc/stm32f3xx_hal_cortex.h \
 D:/PROJECTS/liquidrocketry/Projects/VibrationSensor/FIS-Vibration-Sensor-Driver/vbs-f303ret6/Drivers/STM32F3xx_HAL_Driver/Inc/stm32f3xx_hal_flash.h \
 D:/PROJECTS/liquidrocketry/Projects/VibrationSensor/FIS-Vibration-Sensor-Driver/vbs-f303ret6/Drivers/STM32F3xx_HAL_Driver/Inc/stm32f3xx_hal_flash_ex.h \
 D:/PROJECTS/liquidrocketry/Projects/VibrationSensor/FIS-Vibration-Sensor-Driver/vbs-f303ret6/Drivers/STM32F3xx_HAL_Driver/Inc/stm32f3xx_hal_i2c.h \
 D:/PROJECTS/liquidrocketry/Projects/VibrationSensor/FIS-Vibration-Sensor-Driver/vbs-f303ret6/Drivers/STM32F3xx_HAL_Driver/Inc/stm32f3xx_hal_i2c_ex.h \
 D:/PROJECTS/liquidrocketry/Projects/VibrationSensor/FIS-Vibration-Sensor-Driver/vbs-f303ret6/Drivers/STM32F3xx_HAL_Driver/Inc/stm32f3xx_hal_pwr.h \
 D:/PROJECTS/liquidrocketry/Projects/VibrationSensor/FIS-Vibration-Sensor-Driver/vbs-f303ret6/Drivers/STM32F3xx_HAL_Driver/Inc/stm32f3xx_hal_pwr_ex.h \
 D:/PROJECTS/liquidrocketry/Projects/VibrationSensor/FIS-Vibration-Sensor-Driver/vbs-f303ret6/Drivers/STM32F3xx_HAL_Driver/Inc/stm32f3xx_hal_spi.h \
 D:/PROJECTS/liquidrocketry/Projects/VibrationSensor/FIS-Vibration-Sensor-Driver/vbs-f303ret6/Drivers/STM32F3xx_HAL_Driver/Inc/stm32f3xx_hal_spi_ex.h \
 D:/PROJECTS/liquidrocketry/Projects/VibrationSensor/FIS-Vibration-Sensor-Driver/vbs-f303ret6/Drivers/STM32F3xx_HAL_Driver/Inc/stm32f3xx_hal_uart.h \
 D:/PROJECTS/liquidrocketry/Projects/VibrationSensor/FIS-Vibration-Sensor-Driver/vbs-f303ret6/Drivers/STM32F3xx_HAL_Driver/Inc/stm32f3xx_hal_uart_ex.h \
 D:/PROJECTS/liquidrocketry/Projects/VibrationSensor/FIS-Vibration-Sensor-Driver/vbs-f303ret6/Middlewares/Third_Party/FatFs/src/ff_gen_drv.h \
 D:/PROJECTS/liquidrocketry/Projects/VibrationSensor/FIS-Vibration-Sensor-Driver/vbs-f303ret6/Middlewares/Third_Party/FatFs/src/diskio.h \
 D:/PROJECTS/liquidrocketry/Projects/VibrationSensor/FIS-Vibration-Sensor-Driver/vbs-f303ret6/Middlewares/Third_Party/FatFs/src/ff.h \
 D:/PROJECTS/liquidrocketry/Projects/VibrationSensor/FIS-Vibration-Sensor-Driver/vbs-f303ret6/FATFS/Target/user_diskio.h \
 D:/PROJECTS/liquidrocketry/Projects/VibrationSensor/FIS-Vibration-Sensor-Driver/vbs-f303ret6/Middlewares/Third_Party/FatFs/src/diskio.h \
 C:/Program\ Files/Arm/GNU\ Toolchain\ mingw-w64-x86_64-arm-none-eabi/arm-none-eabi/include/stdio.h \
 C:/Program\ Files/Arm/GNU\ Toolchain\ mingw-w64-x86_64-arm-none-eabi/arm-none-eabi/include/_ansi.h \
 C:/Program\ Files/Arm/GNU\ Toolchain\ mingw-w64-x86_64-arm-none-eabi/arm-none-eabi/include/newlib.h \
 C:/Program\ Files/Arm/GNU\ Toolchain\ mingw-w64-x86_64-arm-none-eabi/arm-none-eabi/include/sys/config.h \
 C:/Program\ Files/Arm/GNU\ Toolchain\ mingw-w64-x86_64-arm-none-eabi/arm-none-eabi/include/machine/ieeefp.h \
 C:/Program\ Files/Arm/GNU\ Toolchain\ mingw-w64-x86_64-arm-none-eabi/arm-none-eabi/include/sys/cdefs.h \
 C:/Program\ Files/Arm/GNU\ Toolchain\ mingw-w64-x86_64-arm-none-eabi/lib/gcc/arm-none-eabi/15.2.1/include/stdarg.h \
 C:/Program\ Files/Arm/GNU\ Toolchain\ mingw-w64-x86_64-arm-none-eabi/arm-none-eabi/include/sys/reent.h \
 C:/Program\ Files/Arm/GNU\ Toolchain\ mingw-w64-x86_64-arm-none-eabi/arm-none-eabi/include/_ansi.h \
 C:/Program\ Files/Arm/GNU\ Toolchain\ mingw-w64-x86_64-arm-none-eabi/arm-none-eabi/include/sys/_types.h \
 C:/Program\ Files/Arm/GNU\ Toolchain\ mingw-w64-x86_64-arm-none-eabi/arm-none-eabi/include/machine/_types.h \
 C:/Program\ Files/Arm/GNU\ Toolchain\ mingw-w64-x86_64-arm-none-eabi/arm-none-eabi/include/sys/lock.h \
 C:/Program\ Files/Arm/GNU\ Toolchain\ mingw-w64-x86_64-arm-none-eabi/arm-none-eabi/include/sys/stdio.h \
 C:/Program\ Files/Arm/GNU\ Toolchain\ mingw-w64-x86_64-arm-none-eabi/arm-none-eabi/include/string.h \
 C:/Program\ Files/Arm/GNU\ Toolchain\ mingw-w64-x86_64-arm-none-eabi/arm-none-eabi/include/sys/_locale.h \
 C:/Program\ Files/Arm/GNU\ Toolchain\ mingw-w64-x86_64-arm-none-eabi/arm-none-eabi/include/strings.h \
 C:/Program\ Files/Arm/GNU\ Toolchain\ mingw-w64-x86_64-arm-none-eabi/arm-none-eabi/include/sys/string.h
